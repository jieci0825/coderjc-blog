// 行为组
const CosAction = {
	UPLOAD: [
		'name/cos:PutObject',
		'name/cos:PostObject',
		'name/cos:InitiateMultipartUpload',
		'name/cos:ListMultipartUploads',
		'name/cos:ListParts',
		'name/cos:UploadPart',
		'name/cos:CompleteMultipartUpload',
		'name/cos:AbortMultipartUpload'
	],
	DOWNLOAD: ['name/cos:GetObject'],
	QUERY: ['name/cos:HeadObject', 'name/cos:GetObject', 'name/cos:GetBucket', 'name/cos:OptionsObject'],
	REMOVE: ['name/cos:DeleteObject']
}

// COS配置项
const CosConfig = {
	SECRETID: 'AKIDCD8bEer8E7wtcDfvyqWKzWzGJD3pQuHX', // 用户的 SecretId
	SECRETKEY: 'PdhdOwITTTUZYVPAwZ1EE1mQvdDLJF83', // 用户的 SecretKey
	APPID: '1312270807', // 用户的 AppID
	BUCKET: 'coderjc-1312270807', // 存储桶名称
	REGION: 'ap-guangzhou', // 地域
	DURATIONSECONDS: 3600, // 有效时长 s
	// 策略
	ALL_POLICY: {
		version: '2.0',
		statement: [
			{
				action: ['*'],
				effect: 'allow',
				resource: ['*']
			}
		]
	}
}

module.exports = {
	CosConfig,
	CosAction
}
